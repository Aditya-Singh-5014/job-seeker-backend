// backend/models/jobModel.js
const db = require("../config/dbConfig");
const util = require("util");

const query = util.promisify(db.query).bind(db);

const Job = {
  createJob: async (jobData) => {
    const { recruiter_id, title, description, location, requirements, salary } =
      jobData;

    const sql = `
      INSERT INTO jobs (recruiter_id, title, description, location, requirements, salary)
      VALUES (?, ?, ?, ?, ?, ?)
    `;

    const values = [
      recruiter_id,
      title,
      description,
      location,
      requirements,
      salary,
    ];

    const result = await query(sql, values);
    return result;
  },

  getJobsByRecruiterId: async (recruiterId) => {
    const sql = `SELECT * FROM jobs WHERE recruiter_id = ?`;
    const results = await query(sql, [recruiterId]);
    return results;
  },

  getAllJobs: async () => {
    const sql = `SELECT * FROM jobs`;
    const results = await query(sql);
    return results;
  },

  getJobById: async (jobId) => {
    const sql = `SELECT * FROM jobs WHERE id = ?`;
    const results = await query(sql, [jobId]);
    return results[0];
  },
};

module.exports = Job;
