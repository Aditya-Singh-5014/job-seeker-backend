// backend/models/jobSeekerProfileModel.js
const db = require("../config/dbConfig");

const JobSeekerProfile = {
  getProfileByUserId: (userId, callback) => {
    const query = `SELECT * FROM job_seeker_profiles WHERE user_id = ?`;
    db.query(query, [userId], callback);
  },
  createProfile: (profileData, callback) => {
    const query = `INSERT INTO job_seeker_profiles (user_id, bio, skills, resume) VALUES (?, ?, ?, ?)`;
    db.query(
      query,
      [
        profileData.user_id,
        profileData.bio || "",
        profileData.skills ? profileData.skills.join(", ") : "",
        profileData.resume || "",
      ],
      callback
    );
  },
  updateProfile: (userId, profileData, callback) => {
    const query = `UPDATE job_seeker_profiles SET bio = ?, skills = ?, resume = ? WHERE user_id = ?`;
    db.query(
      query,
      [
        profileData.bio || "",
        profileData.skills ? profileData.skills.join(", ") : "",
        profileData.resume || "",
        userId,
      ],
      callback
    );
  },
};

module.exports = JobSeekerProfile;
