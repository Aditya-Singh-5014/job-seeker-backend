// backend/models/applicationModel.js
const db = require("../config/dbConfig");
const util = require("util");

const query = util.promisify(db.query).bind(db);

const Application = {
  applyToJob: async (jobId, jobSeekerId) => {
    const sql = `
      INSERT INTO applications (job_id, jobseeker_id, status, date_applied)
      VALUES (?, ?, 'applied', NOW())
    `;
    const result = await query(sql, [jobId, jobSeekerId]);
    return result;
  },

  getApplicationsByJobId: async (jobId) => {
    const sql = `
      SELECT applications.*, job_seekers.name, job_seekers.email
      FROM applications
      JOIN job_seekers ON applications.jobseeker_id = job_seekers.id
      WHERE applications.job_id = ?
    `;
    const results = await query(sql, [jobId]);
    return results;
  },

  checkExistingApplication: async (jobId, jobSeekerId) => {
    const sql = `SELECT * FROM applications WHERE job_id = ? AND jobseeker_id = ?`;
    const results = await query(sql, [jobId, jobSeekerId]);
    return results;
  },
};

module.exports = Application;
