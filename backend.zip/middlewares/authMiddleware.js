// backend/middlewares/authMiddleware.js
const jwt = require("jsonwebtoken");
const JobSeeker = require("../models/jobSeekerModel");

const protect = (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    // Get token from header
    token = req.headers.authorization.split(" ")[1];
    console.log("Received Token:", token); // Debugging

    try {
      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      console.log("Decoded Token:", decoded); // Debugging

      // Get user from the token
      JobSeeker.findById(decoded.id, (err, user) => {
        if (err || !user) {
          console.log("User not found"); // Debugging
          return res
            .status(401)
            .json({ message: "Not authorized, user not found" });
        }
        req.user = user;
        next();
      });
    } catch (error) {
      console.error(error);
      res.status(401).json({ message: "Not authorized, token failed" });
    }
  }

  if (!token) {
    res.status(401).json({ message: "Not authorized, no token" });
  }
};

module.exports = { protect };
